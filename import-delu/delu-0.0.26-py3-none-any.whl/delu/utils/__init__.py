"""An addition to `torch.utils`."""

from . import data

__all__ = ['data']

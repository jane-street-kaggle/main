"""Custom warnings and exceptions."""

__all__ = ['DeLUDeprecationWarning']


class DeLUDeprecationWarning(Warning):
    pass
